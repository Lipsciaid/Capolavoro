package capolavorosg;

import java.util.Scanner;
//import java.util.Random;

public class CapolavoroSG {

    public static void main(String[] args) {
        int altezza = 6;
        System.out.println("//||_//\\\\_||\\\\//||_||\\\\//||_//\\\\_||\\\\");
        System.out.println("Benvenuto nel gioco da tavolo FORZA 4");
        System.out.println("\\\\||_//\\\\_||\\\\//||_||\\\\//||_//\\\\_||//");

        System.out.println(" ");
        System.out.println("Il gioco in cui devi far allineare le X o le O a gruppi da 4 che sia in orrizontale,in verticale o in diagonale");
        System.out.println("I due giocatori mettono la propria mossa selezionando la colonna");
        System.out.println("Il primo giocatore a fare una fila da 4 vince il gioco ottenendo un punto!");
        Scanner tastiera = new Scanner(System.in);
//        Random random = new Random();

//        String currentPlayer = " ";
        String c1[] = new String[altezza];
        String c2[] = new String[altezza];
        String c3[] = new String[altezza];
        String c4[] = new String[altezza];
        String c5[] = new String[altezza];
        String c6[] = new String[altezza];
        String c7[] = new String[altezza];

        char rigioca = 0;
        int punti1 = 0;
        int punti2 = 0;
        //Ciclo Do While per far rigiocare i due giocatori
        do {
            int z = 2;
            int x = 0;
            int w = 1;
            int A = 0;
            int B = 0;
            int C = 0;
            int D = 0;
            int E = 0;
            int F = 0;
            int G = 0;
//            int modalita = 1;
            int scelta = 0;
            int mosse = 42;
            int giocata = 0;
            int punto = 0;
            int punteggio = 0;
            //Ciclo For per resettare la tabella di gioco
            for (int i = 0; i < 6; i++) {
                c1[i] = " ";
                c2[i] = " ";
                c3[i] = " ";
                c4[i] = " ";
                c5[i] = " ";
                c6[i] = " ";
                c7[i] = " ";
            }
            System.out.println(" ");
//            System.out.println("Scegli la modalita di gioco");
//            System.out.println("1. Partita Due giocatori");
//            System.out.println("2. Partita giocatore - bot");
//            modalita = tastiera.nextInt();
//
//            System.out.println(" ");
            System.out.println("   1   2   3   4   5   6   7");

            System.out.println(" | " + c1[5] + " | " + c2[5] + " | " + c3[5] + " | " + c4[5] + " | " + c5[5] + " | " + c6[5] + " | " + c7[5] + " | ");
            System.out.println(" | " + c1[4] + " | " + c2[4] + " | " + c3[4] + " | " + c4[4] + " | " + c5[4] + " | " + c6[4] + " | " + c7[4] + " | ");
            System.out.println(" | " + c1[3] + " | " + c2[3] + " | " + c3[3] + " | " + c4[3] + " | " + c5[3] + " | " + c6[3] + " | " + c7[3] + " | ");
            System.out.println(" | " + c1[2] + " | " + c2[2] + " | " + c3[2] + " | " + c4[2] + " | " + c5[2] + " | " + c6[2] + " | " + c7[2] + " | ");
            System.out.println(" | " + c1[1] + " | " + c2[1] + " | " + c3[1] + " | " + c4[1] + " | " + c5[1] + " | " + c6[1] + " | " + c7[1] + " | ");
            System.out.println(" | " + c1[0] + " | " + c2[0] + " | " + c3[0] + " | " + c4[0] + " | " + c5[0] + " | " + c6[0] + " | " + c7[0] + " | ");
            System.out.println(" -----------------------------");
            System.out.println("Giocatore 1 = X");
            System.out.println("Giocatore 2 = O");
            System.out.println(" ");
            for (int i = 0; i < mosse; i++) {

                for (int y = 0; y < w; y++) {
//                    if (modalita == 1) {

                    System.out.print("Scegli la colonna  in cui giocare la tua mossa da 1 a 7: ");
                    scelta = tastiera.nextInt();
//                    }
//                    if (modalita == 2) {
//                        if (giocata == 0) {
//                            System.out.print("Scegli la colonna  in cui giocare la tua mossa : ");
//                            scelta = tastiera.nextInt();
//                            giocata = giocata + 1;
//                        } else {
//                            scelta = random.nextInt(7)+1;
//                                                        giocata = giocata - 1;
//
//                            y=y+1;
//                        }
//
//                    }
                    if (scelta < 1 || scelta > 7) {
                        System.out.println("Posizione non valida");
                        System.out.println(" ");

                        w = w + 1;
                    }

                    switch (scelta) {
                        case 1:

                            if (A < 6) {
                                if (z == 2) {
                                    c1[A] = "X";
                                    A = A + 1;

                                    z = z - 1;
                                } else {
                                    c1[A] = "O";
                                    A = A + 1;
                                    z = z + 1;
                                }
                            } else {
                                System.out.println("La colonna 1 e' occupata, sceglie ne un'altra");
                                System.out.println(" ");

                                w = w + 1;
                            }

                            break;
                        case 2:
                            if (B < 6) {
                                if (z == 2) {
                                    c2[B] = "X";
                                    B = B + 1;
                                    z = z - 1;
                                } else {
                                    c2[B] = "O";
                                    B = B + 1;
                                    z = z + 1;
                                }
                            } else {
                                System.out.println("La colonna 2 e' occupata, sceglie ne un'altra");
                                System.out.println(" ");

                                w = w + 1;
                            }
                            break;
                        case 3:
                            if (C < 6) {
                                if (z == 2) {
                                    c3[C] = "X";
                                    C = C + 1;
                                    z = z - 1;
                                } else {
                                    c3[C] = "O";
                                    C = C + 1;
                                    z = z + 1;
                                }
                            } else {
                                System.out.println("La colonna 3 e' occupata, sceglie ne un'altra");
                                System.out.println(" ");

                                w = w + 1;
                            }
                            break;
                        case 4:
                            if (D < 6) {
                                if (z == 2) {
                                    c4[D] = "X";
                                    D = D + 1;
                                    z = z - 1;
                                } else {
                                    c4[D] = "O";
                                    D = D + 1;
                                    z = z + 1;
                                }
                            } else {
                                System.out.println("La colonna 4 e' occupata, sceglie ne un'altra");
                                System.out.println(" ");

                                w = w + 1;
                            }
                            break;
                        case 5:
                            if (E < 6) {
                                if (z == 2) {
                                    c5[E] = "X";
                                    E = E + 1;
                                    z = z - 1;
                                } else {
                                    c5[E] = "O";
                                    E = E + 1;
                                    z = z + 1;
                                }
                            } else {
                                System.out.println("La colonna 5 e' occupata, sceglie ne un'altra");
                                System.out.println(" ");

                                w = w + 1;
                            }
                            break;
                        case 6:
                            if (F < 6) {
                                if (z == 2) {
                                    c6[F] = "X";
                                    F = F + 1;
                                    z = z - 1;
                                } else {
                                    c6[F] = "O";
                                    F = F + 1;
                                    z = z + 1;
                                }
                            } else {
                                System.out.println("La colonna 6 e' occupata, sceglie ne un'altra");
                                System.out.println(" ");

                                w = w + 1;
                            }
                            break;

                        case 7:
                            if (G < 6) {
                                if (z == 2) {
                                    c7[G] = "X";
                                    G = G + 1;
                                    z = z - 1;
                                } else {
                                    c7[G] = "O";
                                    G = G + 1;
                                    z = z + 1;
                                }
                            } else {
                                System.out.println("La colonna 7 e' occupata, sceglie ne un'altra");
                                System.out.println(" ");

                                w = w + 1;
                            }
                            break;
                    }
                }
                //Stampa della tabella del gioco da tavolo
                System.out.println(" ");
                System.out.println("   1   2   3   4   5   6   7");
                System.out.println(" | " + c1[5] + " | " + c2[5] + " | " + c3[5] + " | " + c4[5] + " | " + c5[5] + " | " + c6[5] + " | " + c7[5] + " | ");
                System.out.println(" | " + c1[4] + " | " + c2[4] + " | " + c3[4] + " | " + c4[4] + " | " + c5[4] + " | " + c6[4] + " | " + c7[4] + " | ");
                System.out.println(" | " + c1[3] + " | " + c2[3] + " | " + c3[3] + " | " + c4[3] + " | " + c5[3] + " | " + c6[3] + " | " + c7[3] + " | ");
                System.out.println(" | " + c1[2] + " | " + c2[2] + " | " + c3[2] + " | " + c4[2] + " | " + c5[2] + " | " + c6[2] + " | " + c7[2] + " | ");
                System.out.println(" | " + c1[1] + " | " + c2[1] + " | " + c3[1] + " | " + c4[1] + " | " + c5[1] + " | " + c6[1] + " | " + c7[1] + " | ");
                System.out.println(" | " + c1[0] + " | " + c2[0] + " | " + c3[0] + " | " + c4[0] + " | " + c5[0] + " | " + c6[0] + " | " + c7[0] + " | ");
                System.out.println(" -----------------------------");
                System.out.println(" ");

                //ciclo per il controllo se uno dei due giocatori ha vinto(verticale | )
                for (int j = 0; j < 3; j++) {
                    if (c1[j] == c1[j + 1] && c1[j + 1] == c1[j + 2] && c1[j + 2] == c1[j + 3] && c1[j + 2] != " " && punto == 0) {
                        System.out.println("Il giocatore " + z + " ha ottenuto un punto");
                        i = mosse;
                        punto = 1;
                        break;
                    }
                    if (c2[j] == c2[j + 1] && c2[j + 1] == c2[j + 2] && c2[j + 2] == c2[j + 3] && c2[j + 2] != " " && punto == 0) {
                        System.out.println("Il giocatore " + z + " ha ottenuto un punto");
                        i = mosse;
                        punto = 1;
                        break;
                    }
                    if (c3[j] == c3[j + 1] && c3[j + 1] == c3[j + 2] && c3[j + 2] == c3[j + 3] && c3[j + 2] != " " && punto == 0) {
                        System.out.println("Il giocatore " + z + " ha ottenuto un punto");
                        i = mosse;
                        punto = 1;
                        break;
                    }
                    if (c4[j] == c4[j + 1] && c4[j + 1] == c4[j + 2] && c4[j + 2] == c4[j + 3] && c4[j + 2] != " " && punto == 0) {
                        System.out.println("Il giocatore " + z + " ha ottenuto un punto");
                        i = mosse;
                        punto = 1;
                        break;
                    }
                    if (c5[j] == c5[j + 1] && c5[j + 1] == c5[j + 2] && c5[j + 2] == c5[j + 3] && c5[j + 2] != " " && punto == 0) {
                        System.out.println("Il giocatore " + z + " ha ottenuto un punto");
                        i = mosse;
                        punto = 1;
                        break;
                    }
                    if (c6[j] == c6[j + 1] && c6[j + 1] == c6[j + 2] && c6[j + 2] == c6[j + 3] && c6[j + 2] != " " && punto == 0) {
                        System.out.println("Il giocatore " + z + " ha ottenuto un punto");
                        i = mosse;
                        punto = 1;
                        break;
                    }
                    if (c7[j] == c7[j + 1] && c7[j + 1] == c7[j + 2] && c7[j + 2] == c7[j + 3] && c7[j + 2] != " " && punto == 0) {
                        System.out.println("Il giocatore " + z + " ha ottenuto un punto");
                        i = mosse;
                        punto = 1;
                        break;
                    }
                }
                //ciclo per il controllo se uno dei due giocatori ha vinto(orizzontale - )
                for (int j = 0; j < 6; j++) {

                    if (c1[j] == c2[j] && c2[j] == c3[j] && c3[j] == c4[j] && c1[j] != " " && punto == 0) {
                        System.out.println("Il giocatore " + z + " ha ottenuto un punto");
                        i = mosse;
                        punto = 1;
                        break;
                    }
                    if (c2[j] == c3[j] && c3[j] == c4[j] && c4[j] == c5[j] && c2[j] != " " && punto == 0) {
                        System.out.println("Il giocatore " + z + " ha ottenuto un punto");
                        i = mosse;
                        punto = 1;
                        break;
                    }
                    if (c3[j] == c4[j] && c4[j] == c5[j] && c5[j] == c6[j] && c3[j] != " " && punto == 0) {
                        System.out.println("Il giocatore " + z + " ha ottenuto un punto");
                        i = mosse;
                        punto = 1;
                        break;
                    }
                    if (c4[j] == c5[j] && c5[j] == c6[j] && c6[j] == c7[j] && c4[j] != " " && punto == 0) {
                        System.out.println("Il giocatore " + z + " ha ottenuto un punto");
                        i = mosse;
                        punto = 1;
                        break;
                    }
                }
                //ciclo per il controllo se uno dei due giocatori ha vinto(diagonale / )
                for (int j = 0; j < 3; j++) {
                    if (c1[j] == c2[j + 1] && c2[j + 1] == c3[j + 2] && c3[j + 2] == c4[j + 3] && c1[j] != " " && punto == 0) {
                        System.out.println("Il giocatore " + z + " ha ottenuto un punto");
                        i = mosse;
                        punto = 1;
                        break;
                    }
                    if (c2[j] == c3[j + 1] && c3[j + 1] == c4[j + 2] && c4[j + 2] == c5[j + 3] && c2[j] != " " && punto == 0) {
                        System.out.println("Il giocatore " + z + " ha ottenuto un punto");
                        i = mosse;
                        punto = 1;
                        break;
                    }
                    if (c3[j] == c4[j + 1] && c4[j + 1] == c5[j + 2] && c5[j + 2] == c6[j + 3] && c3[j] != " " && punto == 0) {
                        System.out.println("Il giocatore " + z + " ha ottenuto un punto");
                        i = mosse;
                        punto = 1;
                        break;
                    }
                    if (c4[j] == c5[j + 1] && c5[j + 1] == c6[j + 2] && c6[j + 2] == c7[j + 3] && c4[j] != " " && punto == 0) {
                        System.out.println("Il giocatore " + z + " ha ottenuto un punto");
                        i = mosse;
                        punto = 1;
                        break;
                    }
                }
                //ciclo per il controllo se uno dei due giocatori ha vinto(diagonale \ )
                for (int j = 0; j < 3; j++) {
                    if (c7[j] == c6[j + 1] && c6[j + 1] == c5[j + 2] && c5[j + 2] == c4[j + 3] && c7[j] != " " && punto == 0) {
                        System.out.println("Il giocatore " + z + " ha ottenuto un punto");
                        i = mosse;
                        punto = 1;
                        break;
                    }
                    if (c6[j] == c5[j + 1] && c5[j + 1] == c4[j + 2] && c4[j + 2] == c3[j + 3] && c6[j] != " " && punto == 0) {
                        System.out.println("Il giocatore " + z + " ha ottenuto un punto");
                        i = mosse;
                        punto = 1;
                        break;
                    }
                    if (c5[j] == c4[j + 1] && c4[j + 1] == c3[j + 2] && c3[j + 2] == c2[j + 3] && c5[j] != " " && punto == 0) {
                        System.out.println("Il giocatore " + z + " ha ottenuto un punto");
                        i = mosse;
                        punto = 1;
                        break;
                    }
                    if (c4[j] == c3[j + 1] && c3[j + 1] == c2[j + 2] && c2[j + 2] == c1[j + 3] && c4[j] != " " && punto == 0) {
                        System.out.println("Il giocatore " + z + " ha ottenuto un punto");
                        i = mosse;
                        punto = 1;
                        break;
                    }

                }
                w = 1;
                punteggio = punteggio + 1;
            }
            System.out.println(" ");
            if (punteggio < mosse) {
                if (z == 1) {
                    punti1 = punti1 + 1;
                }
                if (z == 2) {
                    punti2 = punti2 + 1;
                }
            } else {
                System.out.println("Nessuno dei due giocatori ha ottenuto un punto");
                System.out.println(" ");

            }
            System.out.println("Punti giocatore 1 : " + punti1);
            System.out.println("Punti giocatore 2 : " + punti2);
            System.out.println(" ");
            System.out.print("Vuoi rigiocare ? S/N: ");

            rigioca = tastiera.next().toLowerCase().charAt(0);
            while (rigioca != 's' && rigioca != 'n') {
                System.out.println("Risposta non adeguata");
                System.out.print("Vuoi rigiocare ? S/N: ");
                rigioca = tastiera.next().toLowerCase().charAt(0);
                System.out.println(" ");

            }
        } while (rigioca == 's');
        System.out.println(" ");
        if (punti1 > punti2) {
            System.out.println("La partita si e conclusa con la vittoria del GIOCATORE 1!");
        }
        if (punti1 < punti2) {
            System.out.println("La partita si e conclusa con la vittoria del GIOCATORE 2!");
        }
        if (punti1 == punti2) {
            System.out.println("La partita si e conclusa con un pareggio");
        }
    }
}
